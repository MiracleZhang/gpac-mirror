#!/bin/sh
cp -r lib/android/armeabi/*.so ../gpac_public/extra_lib/lib/android/armeabi
cp -r lib/android/armeabi-v7a/*.so ../gpac_public/extra_lib/lib/android/armeabi-v7a
cp -r lib/android/x86/*.so ../gpac_public/extra_lib/lib/android/x86
cp -f ../tools/osmo4_android_libs/real3d.jar ../gpac_public/applications/osmo4_android/libs
